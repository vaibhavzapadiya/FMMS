import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MaintenanceSchedulingRoutingModule } from './maintenance-scheduling-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    MaintenanceSchedulingRoutingModule
  ]
})
export class MaintenanceSchedulingModule { }
