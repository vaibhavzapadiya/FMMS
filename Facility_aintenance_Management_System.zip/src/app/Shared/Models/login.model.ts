export interface loginrequest{
    UserName:string;
    passwordHash:string

}